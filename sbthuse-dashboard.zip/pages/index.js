
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function SbthuseDashboard() {
  const sections = [
    {
      title: "Financial Overview",
      tiles: ["Monthly Revenue", "Monthly Expenses", "Net Profit", "Upcoming Payments", "Renewals (30d)"]
    },
    {
      title: "Clients & Projects",
      tiles: ["Total Clients", "Active Projects", "Delayed Projects", "Top Clients by Revenue", "Client Follow-ups Due"]
    },
    {
      title: "Tasks & Workflow",
      tiles: ["Tasks Due Today", "Overdue Tasks", "Recurring Tasks", "Completed This Week", "Blocked/Waiting On"]
    },
    {
      title: "Tools & Subscriptions",
      tiles: ["Hosting Subscriptions", "AI Subscriptions", "SaaS Tools", "Renewal Calendar", "Monthly SaaS Spend"]
    },
    {
      title: "Reports & Insights",
      tiles: ["Weekly Summary", "Finance Trend Graph", "Client Activity Report", "Tool ROI"]
    }
  ];

  return (
    <div className="p-6 grid gap-8">
      <h1 className="text-3xl font-bold">Sbthuse Business Dashboard</h1>
      {sections.map((section) => (
        <div key={section.title}>
          <h2 className="text-xl font-semibold mb-4">{section.title}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {section.tiles.map((tile) => (
              <Card key={tile} className="rounded-2xl shadow p-4">
                <CardContent>
                  <h3 className="font-medium text-lg">{tile}</h3>
                  <p className="text-sm text-gray-500">[Placeholder for data]</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
