import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AuthLayout from '../components/AuthLayout';
import FormInput from '../components/FormInput';
import Button from '../components/Button';
import { useAuth } from '../contexts/AuthContext';

const ResetPassword: React.FC = () => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errors, setErrors] = useState<{ 
    password?: string; 
    confirmPassword?: string;
    general?: string;
  }>({});
  const [isLoading, setIsLoading] = useState(false);
  
  const navigate = useNavigate();
  const { updatePassword } = useAuth();

  const validate = (): boolean => {
    const newErrors: { 
      password?: string; 
      confirmPassword?: string;
    } = {};
    
    if (!password) {
      newErrors.password = 'Password is required';
    } else if (password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }
    
    if (!confirmPassword) {
      newErrors.confirmPassword = 'Please confirm your password';
    } else if (confirmPassword !== password) {
      newErrors.confirmPassword = 'Passwords do not match';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validate()) {
      return;
    }
    
    setIsLoading(true);
    
    try {
      const { error } = await updatePassword(password);
      
      if (error) {
        setErrors({ general: error.message });
      } else {
        // Redirect to login
        navigate('/login', { state: { message: 'Password updated successfully. You can now log in with your new password.' } });
      }
    } catch (error: any) {
      setErrors({ general: error.message || 'An error occurred' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthLayout 
      title="Set new password" 
      subtitle="Create a new password for your account"
    >
      {errors.general && (
        <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md text-sm">
          {errors.general}
        </div>
      )}
      
      <form className="space-y-6" onSubmit={handleSubmit}>
        <FormInput
          id="password"
          name="password"
          type="password"
          label="New Password"
          autoComplete="new-password"
          required
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          error={errors.password}
        />

        <FormInput
          id="confirm-password"
          name="confirmPassword"
          type="password"
          label="Confirm New Password"
          autoComplete="new-password"
          required
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          error={errors.confirmPassword}
        />

        <Button
          type="submit"
          fullWidth
          isLoading={isLoading}
        >
          Update password
        </Button>
      </form>
    </AuthLayout>
  );
};

export default ResetPassword;