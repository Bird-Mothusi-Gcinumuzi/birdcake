import React from 'react';
import { useNavigate } from 'react-router-dom';
import { BanIcon as BankIcon, LogOutIcon, ShoppingCartIcon, HomeIcon } from 'lucide-react';
import Button from '../components/Button';
import { useAuth } from '../contexts/AuthContext';

const Dashboard: React.FC = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center">
              <BankIcon className="h-8 w-8 text-primary" />
              <span className="ml-2 text-xl font-semibold text-primary">Dank of Zar</span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-700">
                {user?.email}
              </span>
              <Button variant="outline" onClick={handleSignOut}>
                <LogOutIcon className="h-4 w-4 mr-2" />
                Sign out
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="py-10">
        <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
          <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div className="p-6 bg-white border-b border-gray-200">
              <h1 className="text-2xl font-semibold text-gray-900 mb-6">Dashboard</h1>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-secondary p-6 rounded-lg shadow-sm">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-primary bg-opacity-10">
                      <HomeIcon className="h-6 w-6 text-primary" />
                    </div>
                    <div className="ml-4">
                      <h2 className="text-lg font-semibold text-gray-900">Browse Products</h2>
                      <p className="text-sm text-gray-600">Explore our full catalog</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-secondary p-6 rounded-lg shadow-sm">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-primary bg-opacity-10">
                      <ShoppingCartIcon className="h-6 w-6 text-primary" />
                    </div>
                    <div className="ml-4">
                      <h2 className="text-lg font-semibold text-gray-900">My Orders</h2>
                      <p className="text-sm text-gray-600">View your order history</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-secondary p-6 rounded-lg shadow-sm">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-primary bg-opacity-10">
                      <svg className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                      </svg>
                    </div>
                    <div className="ml-4">
                      <h2 className="text-lg font-semibold text-gray-900">My Profile</h2>
                      <p className="text-sm text-gray-600">Update your information</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-8">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Activity</h2>
                <div className="bg-white shadow overflow-hidden sm:rounded-md">
                  <ul className="divide-y divide-gray-200">
                    <li className="px-6 py-4 flex items-center">
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium text-primary truncate">Account created</p>
                        <p className="text-sm text-gray-500">
                          {new Date().toLocaleDateString()}
                        </p>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;