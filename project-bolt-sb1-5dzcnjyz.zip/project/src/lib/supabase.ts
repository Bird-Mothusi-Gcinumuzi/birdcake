import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client (replace with your actual project URL and anon key)
// In a real project, these would come from environment variables
const supabaseUrl = 'https://your-project.supabase.co';
const supabaseAnonKey = 'your-anon-key';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);